const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");
const crypto = require("crypto");
const OpenAI = require("openai");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const users = new Map();
const sessions = new Map();

function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

function auth(req, res, next) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  const userId = sessions.get(token);
  if (!userId || !users.has(userId)) return res.status(401).json({ error: "Авторизуйтесь" });
  req.user = users.get(userId);
  next();
}

function cleanText(value, max = 3000) {
  return String(value || "").trim().slice(0, max);
}

app.post("/api/register", (req, res) => {
  const email = cleanText(req.body.email, 120).toLowerCase();
  const password = String(req.body.password || "");
  if (!email || password.length < 6) return res.status(400).json({ error: "Email және кемінде 6 таңбалы пароль керек" });
  if ([...users.values()].some(u => u.email === email)) return res.status(409).json({ error: "Бұл email бұрын тіркелген" });

  const id = crypto.randomUUID();
  users.set(id, { id, email, password: hashPassword(password), plan: "free", history: [] });
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, id);
  res.json({ token, user: { email, plan: "free" } });
});

app.post("/api/login", (req, res) => {
  const email = cleanText(req.body.email, 120).toLowerCase();
  const password = String(req.body.password || "");
  const user = [...users.values()].find(u => u.email === email);
  if (!user || user.password !== hashPassword(password)) return res.status(401).json({ error: "Email немесе пароль қате" });

  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, user.id);
  res.json({ token, user: { email: user.email, plan: user.plan } });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ user: { email: req.user.email, plan: req.user.plan } });
});

app.get("/api/history", auth, (req, res) => {
  res.json({ history: req.user.history });
});

app.post("/api/premium/demo", auth, (req, res) => {
  req.user.plan = "premium";
  res.json({ ok: true, plan: "premium", note: "Бұл тек демонстрациялық Premium. Нақты төлем қосылмаған." });
});

app.post("/api/generate", auth, async (req, res) => {
  const type = cleanText(req.body.type, 100);
  const business = cleanText(req.body.business, 1000);
  const language = cleanText(req.body.language, 50) || "Русский";
  const details = cleanText(req.body.details, 2500);

  if (!type || !business) return res.status(400).json({ error: "Қызмет түрі мен бизнес туралы ақпаратты енгізіңіз" });

  const limit = req.user.plan === "premium" ? 100 : 10;
  if (req.user.history.length >= limit) {
    return res.status(403).json({ error: "Free лимит аяқталды. Premium режимін қосыңыз." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: "OPENAI_API_KEY серверде орнатылмаған" });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const prompt = `Сен Rio атты Қазақстандағы шағын бизнеске арналған кәсіби AI-көмекшісің.
Мақсат: дайын, нақты, сатуға бағытталған контент жасау.
Бизнес: ${business}
Тапсырма: ${type}
Тіл: ${language}
Қосымша ақпарат: ${details || "жоқ"}

Ережелер:
- Бірден қолдануға болатын нәтиже бер.
- Артық түсіндірме мен бос сөзді азайт.
- Қазақстан аудиториясына табиғи тіл қолдан.
- Егер Instagram мәтіні болса, қысқа hook, негізгі мәтін және әрекетке шақыру (CTA) бер.
- Егер клиентке жауап болса, сыпайы әрі сенімді жауап жаз.
- Егер Reels сценарийі болса, кадрларға бөліп бер.
- Тек сұралған нәтижені жаса.`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      input: prompt
    });

    const result = response.output_text?.trim() || "Нәтиже алынбады.";
    req.user.history.unshift({
      id: crypto.randomUUID(),
      type,
      business,
      language,
      details,
      result,
      createdAt: new Date().toISOString()
    });
    req.user.history = req.user.history.slice(0, 100);

    res.json({ result });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "AI сұранысы орындалмады. API key және модель параметрлерін тексеріңіз." });
  }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Rio is running on port ${port}`));
