RIO AI APP v4
================

Бұл — Rio AI Business Assistant-тың жақсартылған, телефоннан да қолдануға болатын PWA/web-app нұсқасы.

МҮМКІНДІКТЕР
- AI арқылы Instagram посты
- Reels сценарийі
- Өнім сипаттамасы
- Клиентке жауап
- Жарнама мәтіні
- Қазақша ↔ Русский аударма
- Тіркелу / кіру
- Генерация тарихы
- Premium demo
- Телефонда standalone app ретінде орнатуға дайын PWA

ІСКЕ ҚОСУ
1. Node.js орнатылған компьютерде осы папкаға кір.
2. npm install
3. .env.example файлын .env деп көшір.
4. .env ішіне OPENAI_API_KEY енгіз.
5. npm start
6. Браузерден http://localhost:3000 аш.

DEPLOY
Render сияқты Node.js Web Service-ке GitHub арқылы жүктеуге болады.
Build command: npm install
Start command: npm start

МАҢЫЗДЫ
- API key-ді GitHub-қа қоспа.
- Қазіргі users/history жадыда сақталады: сервер қайта іске қосылса, өшеді.
- Premium — демонстрациялық режим, нақты төлем жоқ.
- Нағыз production нұсқасына PostgreSQL/Supabase, қауіпсіз password hashing, real payment және тұрақты auth қажет.
