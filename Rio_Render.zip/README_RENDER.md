# Rio AI — Render

1. Upload the CONTENTS of this ZIP to GitHub (not the ZIP file itself).
2. Render → New → Web Service → connect the GitHub repository.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Add `OPENAI_API_KEY` in Render Environment Variables.
6. `OPENAI_MODEL` can be `gpt-5.6-luna`.
7. Create Web Service.

Test after deployment:
`https://YOUR-SERVICE.onrender.com/api/health`

Keep the OpenAI API key only in Render Environment Variables, never in GitHub or frontend code.

This is an MVP: users/history are stored in memory. For production, use a database and stronger authentication.
